//
//  SelfSaveViewController.h
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import "HSRootViewController.h"

@interface SelfSaveViewController : HSRootViewController

@end

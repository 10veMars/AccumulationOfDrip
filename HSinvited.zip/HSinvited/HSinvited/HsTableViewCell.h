//
//  HsTableViewCell.h
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HsTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIImageView *tableImage;

@property (strong, nonatomic) IBOutlet UIImageView *cellImage;

@property (strong, nonatomic) IBOutlet UITextField *tableFieldText;

@property (nonatomic, copy) void(^textSource)(NSString *Fieldtext, NSIndexPath *indexPath);

@property (strong, nonatomic) IBOutlet UIImageView *imageback;

@property (strong, nonatomic) NSIndexPath *indexpath;




@end

//
//  HsTableview.h
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol selectTableViewRowDate <NSObject>

- (void)selectTableViewRowDate:(NSMutableArray *)arr ;

@end

@interface HsTableview : UITableView

@property (nonatomic,assign) id<selectTableViewRowDate>  delegateSelect;


- (instancetype)initWithFrame:(CGRect)frame andGetArrary:(NSArray *)soures;

@end

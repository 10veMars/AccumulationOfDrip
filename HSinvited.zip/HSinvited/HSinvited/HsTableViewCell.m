//
//  HsTableViewCell.m
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import "HsTableViewCell.h"

@interface HsTableViewCell ()<UITextFieldDelegate>
{
}
@end
@implementation HsTableViewCell

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    NSLog(@"------%s",__func__);
    
    if (self.textSource) {
        self.textSource(textField.text,self.indexpath);

    }
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    NSLog(@"%s",__func__);

}

- (void)textFieldEditingChanged: (UITextField *)textfiled
{
    NSLog(@"%s",__func__);
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"textFieldShouldReturn");
    [textField resignFirstResponder];
    return YES;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    
    if (self) {
        

        
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

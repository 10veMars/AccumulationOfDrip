//
//  HsTableview.m
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import "HsTableview.h"

#import "HsTableViewCell.h"

#import "HsModelDate.h"

@interface HsTableview()<UITableViewDataSource>
{
    
    NSMutableArray *sourceDate ;
   
    HsModelDate *modearr;
    
}

@end

@implementation HsTableview


- (instancetype)initWithFrame:(CGRect)frame
                 andGetArrary:(NSMutableArray *)soures
{
    
    self = [super initWithFrame:frame];
    if (self) {
        
        self.dataSource = self;
        //属性设置
        [self setSeparatorStyle:UITableViewCellSeparatorStyleNone];
        self.backgroundColor = [UIColor clearColor];

        sourceDate = [[NSMutableArray alloc] init];


        for (int i = 0; i < 4; i++) {
            
            [sourceDate addObject:@"1"];
            
        }
       
        modearr = [HsModelDate sharedSoundTool];

        if (modearr.dateSource.count == 0) {
            modearr.dateSource = sourceDate;

        }

    }
    return self;
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 60;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section == 0) {
        return 4;
    }else{
        return 1;
    }
    
}



- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{

    if (section == 1) {
        
        UIView *view = [[UIView alloc] initWithFrame:[UIScreen mainScreen].bounds];
        
        
        view.backgroundColor = [UIColor clearColor];
        
        return view;
        
    }else
    {
        return nil;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //指定cellIdentifier为自定义的cell
    static NSString *CellIdentifier = @"HsTableViewCell";
    
    NSArray *arr = @[@"交易-撤单",@"交易-查询",@"交易-买入",@"交易-卖出"];
    
    
    //自定义cell类
    HsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (indexPath.section == 0) {
        
        if (cell == nil) {
            //通过xib的名称加载自定义的cell
            cell = [[[NSBundle mainBundle] loadNibNamed:@"HsTableViewCell" owner:self options:nil] firstObject];
            
            cell.cellImage.image = [UIImage imageNamed:arr[indexPath.row]];
            
            if (indexPath.row == 3) {
                
                cell.tableImage.hidden  = YES;
            }
            
            cell.imageback.userInteractionEnabled = YES;
      
            cell.indexpath = indexPath;
        }

        
        if (![modearr.dateSource[indexPath.row] isEqualToString:@"1"]) {
            cell.tableFieldText.text = modearr.dateSource[indexPath.row];
        }
   
            [modearr.dateSource replaceObjectAtIndex:indexPath.row withObject:cell.tableFieldText.text];
            
        
        cell.textSource = ^(NSString  *textField,NSIndexPath *indexpaths)
        {
            
            [modearr.dateSource replaceObjectAtIndex:indexpaths.row withObject:textField];
            
        };
        
        if ([self.delegateSelect respondsToSelector:@selector(selectTableViewRowDate:)]) {
            [self.delegateSelect selectTableViewRowDate:modearr.dateSource];
        }
        
        [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        // 3点击没有颜色改变
        cell.selected = NO;

    }else{
        if (cell == nil) {
            //通过xib的名称加载自定义的cell
            cell = [[[NSBundle mainBundle] loadNibNamed:@"HsTableViewCell" owner:self options:nil] lastObject];
        }
       
    }
    
      return cell;
    
}






/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end

//
//  HsModelDate.h
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HsModelDate : NSObject

@property (nonatomic,strong) NSString *text1;
@property (nonatomic,strong) NSString *text2;
@property (nonatomic,strong) NSString *text3;
@property (nonatomic,strong) NSString *text4;
@property (nonatomic,strong) NSMutableArray *dateSource;


+(instancetype)sharedSoundTool;

@end

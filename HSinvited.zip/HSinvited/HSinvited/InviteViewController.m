//
//  InviteViewController.m
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import "InviteViewController.h"
#import "HsTableview.h"


@interface InviteViewController ()<selectTableViewRowDate,UITableViewDelegate>
{
    HsTableview *infoTableView;
    
    NSMutableArray *sources;
    NSMutableArray *sourcesDate;


}
@end

@implementation InviteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    if( ([[[UIDevice currentDevice] systemVersion] doubleValue]>=7.0)) {
        self.edgesForExtendedLayout = UIRectEdgeNone;
        self.extendedLayoutIncludesOpaqueBars = NO;
        self.modalPresentationCapturesStatusBarAppearance = NO;
    }
    
    NSArray *arr = [[NSArray alloc] init];
    
    UIImageView *image = [[UIImageView alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    image.image = [UIImage imageNamed:@"2"];
    
    image.userInteractionEnabled = YES;
    
    [self.view addSubview:image];
    
    infoTableView = [[HsTableview alloc] initWithFrame:[UIScreen mainScreen].bounds andGetArrary:arr];
   
    infoTableView.delegateSelect = self;
    infoTableView.delegate = self;
    [image addSubview:infoTableView];
    
    [infoTableView reloadData];
    
}

- (void)selectTableViewRowDate:(NSMutableArray *)arr
{

    sourcesDate = arr;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if (indexPath.section == 0) {
        
        
        NSLog(@"%s",__func__);
        
    }else{
        
        NSLog(@"%s",__func__);

        [infoTableView reloadData];

        if ([self.infoMessDelegate respondsToSelector:@selector(cellOfInfoMessWithArray:)]) {
            [self.infoMessDelegate cellOfInfoMessWithArray:sourcesDate];
            
        }
        
        [self dismissViewControllerAnimated:YES completion:^{
            
        }];
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 60;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  HSRootViewController.m
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import "HSRootViewController.h"

#import "InviteViewController.h"

#import "HsModelDate.h"
@interface HSRootViewController ()<tableCellOfInfoMess>

{
    UILabel *label;
    
}
@end

@implementation HSRootViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    label = [[UILabel alloc] initWithFrame:CGRectMake(100, 200, 120, 200)];
    label.text = @"";
    label.textColor = [UIColor blackColor];
    label.backgroundColor = [UIColor greenColor];
    label.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:label];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    
    
}

- (void)cellOfInfoMessWithArray:(NSMutableArray *)source
{
    
    NSString *str = nil;
    
    for (int i = 0; i < source.count; i++) {
     
        if ( [source[i] length] != 0) {
            str = source[i];
        }
    }
    
    label.text = str;
    
    NSLog(@"----++++ %@ +++-----",source);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    InviteViewController *invite = [[InviteViewController alloc] init];
    
    invite.infoMessDelegate = self;
    
    [self presentViewController:invite animated: YES completion:nil];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

//
//  HSRootViewController.h
//  HSinvited
//
//  Created by HundSun on 17/3/29.
//  Copyright © 2017年 HundSun. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface HSRootViewController : UIViewController


@end
